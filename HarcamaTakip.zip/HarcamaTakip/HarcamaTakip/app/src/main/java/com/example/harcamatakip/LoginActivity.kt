package com.example.harcamatakip

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.harcamatakip.databinding.ActivityLoginBinding
import com.google.android.material.snackbar.Snackbar

class LoginActivity : AppCompatActivity() {

    // ViewBinding: XML alanlarına kod tarafından erişim sağlar
    private lateinit var binding: ActivityLoginBinding

    // SharedPreferences: kullanıcı oturum bilgisini saklamak için
    private lateinit var sharedPreferences: SharedPreferences

    // Demo kullanıcı bilgileri (gerçek uygulamada veritabanında tutulur)
    private val DEMO_KULLANICI = "admin"
    private val DEMO_SIFRE = "1234"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ViewBinding başlat
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // SharedPreferences başlat
        sharedPreferences = getSharedPreferences("HarcamaApp", MODE_PRIVATE)

        // Eğer kullanıcı zaten giriş yaptıysa, direkt MainActivity'e git
        if (kullanicoGirisYaptiMi()) {
            mainActivityeGit()
            return
        }

        // Giriş butonu tıklama olayı
        binding.btnGirisYap.setOnClickListener {
            girisYapmayi()
        }
    }

    // Giriş işlemini gerçekleştir
    private fun girisYapmayi() {
        val kullaniciAdi = binding.etKullaniciAdi.text.toString().trim()
        val sifre = binding.etSifre.text.toString().trim()

        // Boş alan kontrolü
        if (kullaniciAdi.isEmpty()) {
            binding.tilKullaniciAdi.error = "Kullanıcı adı boş olamaz"
            return
        } else {
            binding.tilKullaniciAdi.error = null
        }

        if (sifre.isEmpty()) {
            binding.tilSifre.error = "Şifre boş olamaz"
            return
        } else {
            binding.tilSifre.error = null
        }

        // Kullanıcı bilgilerini kontrol et
        if (kullaniciAdi == DEMO_KULLANICI && sifre == DEMO_SIFRE) {
            // Giriş başarılı - oturum bilgisini kaydet
            sharedPreferences.edit()
                .putBoolean("giris_yapildi", true)
                .putString("kullanici_adi", kullaniciAdi)
                .apply()

            // MainActivity'e geç
            mainActivityeGit()
        } else {
            // Yanlış bilgi
            Snackbar.make(
                binding.root,
                "Kullanıcı adı veya şifre yanlış!",
                Snackbar.LENGTH_LONG
            ).show()
        }
    }

    // Kullanıcı daha önce giriş yaptı mı?
    private fun kullanicoGirisYaptiMi(): Boolean {
        return sharedPreferences.getBoolean("giris_yapildi", false)
    }

    // MainActivity'e yönlendir
    private fun mainActivityeGit() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()  // LoginActivity'i kapat (geri dönemesin)
    }
}
