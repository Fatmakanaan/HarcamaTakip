package com.example.harcamatakip.database

import androidx.room.Entity
import androidx.room.PrimaryKey

// Room veritabanı tablosu - her alan bir sütuna karşılık gelir
@Entity(tableName = "harcamalar")
data class Harcama(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,            // Otomatik artan birincil anahtar
    val baslik: String,         // Harcama başlığı (örn: "Market alışverişi")
    val kategori: String,       // Kategori (örn: "Yiyecek", "Ulaşım")
    val tutar: Double,          // Harcama tutarı
    val tarih: String           // Tarih (örn: "2024-01-15")
)
