package com.example.harcamatakip.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

// Room veritabanı sınıfı
// entities: hangi tablolar var, version: veritabanı versiyonu
@Database(entities = [Harcama::class], version = 1, exportSchema = false)
abstract class HarcamaDatabase : RoomDatabase() {

    // DAO'ya erişim sağlayan abstract fonksiyon
    abstract fun harcamaDao(): HarcamaDao

    companion object {
        // Singleton pattern - uygulama boyunca tek bir veritabanı örneği
        @Volatile
        private var INSTANCE: HarcamaDatabase? = null

        fun getDatabase(context: Context): HarcamaDatabase {
            // Eğer daha önce oluşturulduysa, aynı örneği döndür
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    HarcamaDatabase::class.java,
                    "harcama_database"  // Veritabanı dosya adı
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
