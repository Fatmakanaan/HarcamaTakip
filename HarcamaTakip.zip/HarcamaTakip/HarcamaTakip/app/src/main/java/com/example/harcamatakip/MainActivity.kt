package com.example.harcamatakip

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.harcamatakip.adapter.HarcamaAdapter
import com.example.harcamatakip.api.RetrofitClient
import com.example.harcamatakip.database.Harcama
import com.example.harcamatakip.database.HarcamaDatabase
import com.example.harcamatakip.databinding.ActivityMainBinding
import com.example.harcamatakip.databinding.DialogHarcamaDuzenleBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // Veritabanı ve adapter
    private lateinit var harcamaDatabase: HarcamaDatabase
    private lateinit var harcamaAdapter: HarcamaAdapter

    // Kategori listesi
    private val kategoriler = listOf(
        "Yiyecek & İçecek",
        "Ulaşım",
        "Eğlence",
        "Sağlık",
        "Giyim",
        "Faturalar",
        "Eğitim",
        "Diğer"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Toolbar'ı ayarla
        setSupportActionBar(binding.toolbar)

        // Veritabanını başlat
        harcamaDatabase = HarcamaDatabase.getDatabase(this)

        // RecyclerView'i kur
        recyclerViewKur()

        // Kategori dropdown'ını doldur
        kategorileriBelirle()

        // Tarih seçici ayarla
        tarihSeciciAyarla()

        // Harcama ekle butonuna tıklama
        binding.btnHarcamaEkle.setOnClickListener {
            harcamaEkle()
        }

        // Geçmiş butonuna tıklama
        binding.btnGecmis.setOnClickListener {
            val intent = Intent(this, HistoryActivity::class.java)
            startActivity(intent)
        }

        // Döviz kurlarını yükle
        dovizKurlariYukle()

        // Harcamaları yükle
        harcamalariYukle()
    }

    // Activity ekrana geldiğinde verileri yenile
    override fun onResume() {
        super.onResume()
        harcamalariYukle()
    }

    // Toolbar menüsünü oluştur
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    // Toolbar menü tıklamalarını işle
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_cikis -> {
                cikisYap()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    // RecyclerView kurulumu
    private fun recyclerViewKur() {
        harcamaAdapter = HarcamaAdapter(
            mutableListOf(),
            onDuzenleClick = { harcama ->
                harcamaDuzenlemeDialogGoster(harcama)
            },
            onSilClick = { harcama ->
                silmeOnayiGoster(harcama)
            }
        )

        binding.recyclerViewHarcamalar.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = harcamaAdapter
            // NestedScrollView içinde olduğu için
            isNestedScrollingEnabled = false
        }
    }

    // Kategori dropdown'ını doldur
    private fun kategorileriBelirle() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, kategoriler)
        binding.actvKategori.setAdapter(adapter)
    }

    // Tarih seçici kurulumu
    private fun tarihSeciciAyarla() {
        // Bugünün tarihini başlangıç değeri olarak ayarla
        val bugun = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        binding.etTarih.setText(bugun)

        // Tarih alanına tıklayınca DatePickerDialog aç
        binding.etTarih.setOnClickListener {
            tarihSeciciAc(binding.etTarih)
        }
        binding.tilTarih.setEndIconOnClickListener {
            tarihSeciciAc(binding.etTarih)
        }
    }

    // DatePickerDialog'u aç
    private fun tarihSeciciAc(editText: com.google.android.material.textfield.TextInputEditText) {
        val calendar = Calendar.getInstance()
        DatePickerDialog(
            this,
            { _, yil, ay, gun ->
                val tarih = String.format("%04d-%02d-%02d", yil, ay + 1, gun)
                editText.setText(tarih)
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    // Yeni harcama ekle
    private fun harcamaEkle() {
        val baslik = binding.etBaslik.text.toString().trim()
        val kategori = binding.actvKategori.text.toString().trim()
        val tutarStr = binding.etTutar.text.toString().trim()
        val tarih = binding.etTarih.text.toString().trim()

        // Validasyon kontrolleri
        if (baslik.isEmpty()) {
            binding.tilBaslik.error = "Başlık gerekli"
            return
        } else binding.tilBaslik.error = null

        if (kategori.isEmpty() || kategori !in kategoriler) {
            binding.tilKategori.error = "Kategori seçin"
            return
        } else binding.tilKategori.error = null

        if (tutarStr.isEmpty()) {
            binding.tilTutar.error = "Tutar gerekli"
            return
        } else binding.tilTutar.error = null

        val tutar = tutarStr.toDoubleOrNull()
        if (tutar == null || tutar <= 0) {
            binding.tilTutar.error = "Geçerli bir tutar girin"
            return
        } else binding.tilTutar.error = null

        if (tarih.isEmpty()) {
            binding.tilTarih.error = "Tarih gerekli"
            return
        } else binding.tilTarih.error = null

        // Harcama nesnesini oluştur
        val yeniHarcama = Harcama(
            baslik = baslik,
            kategori = kategori,
            tutar = tutar,
            tarih = tarih
        )

        // Veritabanına kaydet (coroutine ile)
        lifecycleScope.launch {
            try {
                harcamaDatabase.harcamaDao().harcamaEkle(yeniHarcama)

                // UI thread'de güncelle
                runOnUiThread {
                    // Formu temizle
                    binding.etBaslik.text?.clear()
                    binding.actvKategori.text?.clear()
                    binding.etTutar.text?.clear()
                    // Tarihi bugüne sıfırla
                    val bugun = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                    binding.etTarih.setText(bugun)

                    Snackbar.make(binding.root, "Harcama başarıyla eklendi!", Snackbar.LENGTH_SHORT).show()

                    // Listeyi yenile
                    harcamalariYukle()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Snackbar.make(binding.root, "Hata: ${e.message}", Snackbar.LENGTH_LONG).show()
                }
            }
        }
    }

    // Harcamaları veritabanından yükle
    private fun harcamalariYukle() {
        lifecycleScope.launch {
            val harcamalar = harcamaDatabase.harcamaDao().tumHarcamalariGetir()
            val toplam = harcamaDatabase.harcamaDao().toplamTutarGetir() ?: 0.0

            runOnUiThread {
                // Adapter'ı güncelle
                harcamaAdapter.listeGuncelle(harcamalar)

                // Toplam tutarı göster
                binding.tvToplamHarcama.text = String.format("%.2f ₺", toplam)

                // Boş liste mesajını göster/gizle
                if (harcamalar.isEmpty()) {
                    binding.tvBosListe.visibility = View.VISIBLE
                    binding.recyclerViewHarcamalar.visibility = View.GONE
                } else {
                    binding.tvBosListe.visibility = View.GONE
                    binding.recyclerViewHarcamalar.visibility = View.VISIBLE
                }
            }
        }
    }

    // Düzenleme dialog'unu göster
    private fun harcamaDuzenlemeDialogGoster(harcama: Harcama) {
        val dialogBinding = DialogHarcamaDuzenleBinding.inflate(layoutInflater)

        // Mevcut değerleri doldur
        dialogBinding.etDuzenleBaslik.setText(harcama.baslik)
        dialogBinding.actvDuzenleKategori.setText(harcama.kategori)
        dialogBinding.etDuzenleTutar.setText(harcama.tutar.toString())
        dialogBinding.etDuzenleTarih.setText(harcama.tarih)

        // Kategori dropdown'ını ayarla
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, kategoriler)
        dialogBinding.actvDuzenleKategori.setAdapter(adapter)

        // Tarih seçici
        dialogBinding.etDuzenleTarih.setOnClickListener {
            tarihSeciciAc(dialogBinding.etDuzenleTarih)
        }
        dialogBinding.tilDuzenleTarih.setEndIconOnClickListener {
            tarihSeciciAc(dialogBinding.etDuzenleTarih)
        }

        // Dialog'u oluştur
        val dialog = MaterialAlertDialogBuilder(this)
            .setView(dialogBinding.root)
            .setCancelable(true)
            .create()

        // İptal butonu
        dialogBinding.btnDuzenleIptal.setOnClickListener {
            dialog.dismiss()
        }

        // Kaydet butonu
        dialogBinding.btnDuzenleKaydet.setOnClickListener {
            val yeniBaslik = dialogBinding.etDuzenleBaslik.text.toString().trim()
            val yeniKategori = dialogBinding.actvDuzenleKategori.text.toString().trim()
            val yeniTutarStr = dialogBinding.etDuzenleTutar.text.toString().trim()
            val yeniTarih = dialogBinding.etDuzenleTarih.text.toString().trim()

            // Basit validasyon
            if (yeniBaslik.isEmpty() || yeniKategori.isEmpty() || yeniTutarStr.isEmpty() || yeniTarih.isEmpty()) {
                Snackbar.make(binding.root, "Tüm alanları doldurun!", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val yeniTutar = yeniTutarStr.toDoubleOrNull()
            if (yeniTutar == null || yeniTutar <= 0) {
                Snackbar.make(binding.root, "Geçerli bir tutar girin!", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Güncellenmiş harcama nesnesi (aynı id ile)
            val guncelHarcama = harcama.copy(
                baslik = yeniBaslik,
                kategori = yeniKategori,
                tutar = yeniTutar,
                tarih = yeniTarih
            )

            lifecycleScope.launch {
                harcamaDatabase.harcamaDao().harcamaGuncelle(guncelHarcama)
                runOnUiThread {
                    dialog.dismiss()
                    Snackbar.make(binding.root, "Harcama güncellendi!", Snackbar.LENGTH_SHORT).show()
                    harcamalariYukle()
                }
            }
        }

        dialog.show()
    }

    // Silme onayı göster
    private fun silmeOnayiGoster(harcama: Harcama) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Harcamayı Sil")
            .setMessage("\"${harcama.baslik}\" harcamasını silmek istediğinizden emin misiniz?")
            .setNegativeButton("İptal") { dialog, _ ->
                dialog.dismiss()
            }
            .setPositiveButton("Sil") { dialog, _ ->
                lifecycleScope.launch {
                    harcamaDatabase.harcamaDao().harcamaSil(harcama)
                    runOnUiThread {
                        dialog.dismiss()
                        Snackbar.make(binding.root, "Harcama silindi", Snackbar.LENGTH_SHORT).show()
                        harcamalariYukle()
                    }
                }
            }
            .show()
    }

    // Döviz kurlarını API'den çek
    private fun dovizKurlariYukle() {
        binding.progressBarDoviz.visibility = View.VISIBLE
        binding.layoutDoviz.visibility = View.GONE
        binding.tvDovizHata.visibility = View.GONE

        lifecycleScope.launch {
            try {
                // USD bazlı kurları çek
                val response = RetrofitClient.dovizApi.dovizKurlariGetir("USD")

                if (response.result == "success") {
                    val tryKuru = response.rates["TRY"] ?: 0.0    // 1 USD = ? TRY
                    val eurKuru = response.rates["EUR"] ?: 0.0    // 1 USD = ? EUR

                    // EUR/TRY hesapla: 1 EUR = (TRY/EUR) TRY
                    val eurTryKuru = if (eurKuru > 0) tryKuru / eurKuru else 0.0

                    // 1 TRY = ? USD
                    val tryUsdKuru = if (tryKuru > 0) 1.0 / tryKuru else 0.0

                    runOnUiThread {
                        binding.tvUsd.text = String.format("%.2f", tryKuru)       // 1 USD kaç TRY
                        binding.tvEur.text = String.format("%.2f", eurTryKuru)    // 1 EUR kaç TRY
                        binding.tvTry.text = String.format("%.4f", tryUsdKuru)    // 1 TRY kaç USD

                        binding.progressBarDoviz.visibility = View.GONE
                        binding.layoutDoviz.visibility = View.VISIBLE
                    }
                } else {
                    throw Exception("API yanıt hatası")
                }

            } catch (e: Exception) {
                runOnUiThread {
                    binding.progressBarDoviz.visibility = View.GONE
                    binding.tvDovizHata.visibility = View.VISIBLE
                    binding.tvDovizHata.text = "Döviz bilgileri yüklenemedi.\n(İnternet bağlantısını kontrol edin)"
                }
            }
        }
    }

    // Çıkış yap
    private fun cikisYap() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Çıkış Yap")
            .setMessage("Çıkış yapmak istediğinize emin misiniz?")
            .setNegativeButton("İptal") { dialog, _ -> dialog.dismiss() }
            .setPositiveButton("Çıkış Yap") { _, _ ->
                // Oturum bilgisini temizle
                getSharedPreferences("HarcamaApp", MODE_PRIVATE)
                    .edit()
                    .clear()
                    .apply()

                // LoginActivity'e git
                val intent = Intent(this, LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            }
            .show()
    }
}
