package com.example.harcamatakip.database

import androidx.room.*

// DAO - Veritabanı işlemlerini tanımladığımız arayüz
@Dao
interface HarcamaDao {

    // Tüm harcamaları getir (en yeniden eskiye sırala)
    @Query("SELECT * FROM harcamalar ORDER BY id DESC")
    suspend fun tumHarcamalariGetir(): List<Harcama>

    // Yeni harcama ekle
    @Insert
    suspend fun harcamaEkle(harcama: Harcama)

    // Mevcut harcamayı güncelle
    @Update
    suspend fun harcamaGuncelle(harcama: Harcama)

    // Harcama sil
    @Delete
    suspend fun harcamaSil(harcama: Harcama)

    // Toplam harcama tutarını hesapla
    @Query("SELECT SUM(tutar) FROM harcamalar")
    suspend fun toplamTutarGetir(): Double?

    // ID'ye göre tek harcama getir
    @Query("SELECT * FROM harcamalar WHERE id = :harcamaId")
    suspend fun idIleGetir(harcamaId: Int): Harcama?

    // Kategoriye göre harcamaları filtrele
    @Query("SELECT * FROM harcamalar WHERE kategori = :kategori ORDER BY id DESC")
    suspend fun kategoriyeGoreGetir(kategori: String): List<Harcama>
}
