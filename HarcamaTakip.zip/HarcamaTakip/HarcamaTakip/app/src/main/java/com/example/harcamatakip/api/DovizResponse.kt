package com.example.harcamatakip.api

import com.google.gson.annotations.SerializedName

// exchangerate-api.com'dan gelen JSON yanıtının modeli
// Örnek yanıt: {"result":"success","base_code":"USD","rates":{"TRY":32.5,"EUR":0.92,...}}
data class DovizResponse(
    @SerializedName("result")
    val result: String,         // "success" veya "error"

    @SerializedName("base_code")
    val baseCode: String,       // Temel para birimi (USD)

    @SerializedName("rates")
    val rates: Map<String, Double>  // Döviz kurları {"TRY": 32.5, "EUR": 0.92}
)
