package com.example.harcamatakip.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.harcamatakip.database.Harcama
import com.example.harcamatakip.databinding.ItemHarcamaBinding

// RecyclerView Adapter - harcama listesini ekranda gösterir
class HarcamaAdapter(
    private var harcamaListesi: MutableList<Harcama>,
    private val onDuzenleClick: (Harcama) -> Unit,  // Düzenle butonuna tıklandığında çağrılır
    private val onSilClick: (Harcama) -> Unit        // Sil butonuna tıklandığında çağrılır
) : RecyclerView.Adapter<HarcamaAdapter.HarcamaViewHolder>() {

    // ViewHolder: her liste öğesinin görünümünü tutar
    inner class HarcamaViewHolder(val binding: ItemHarcamaBinding) :
        RecyclerView.ViewHolder(binding.root)

    // Yeni ViewHolder oluştur - item_harcama.xml'i inflate et
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HarcamaViewHolder {
        val binding = ItemHarcamaBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return HarcamaViewHolder(binding)
    }

    // ViewHolder'a veri bağla - her satır için çağrılır
    override fun onBindViewHolder(holder: HarcamaViewHolder, position: Int) {
        val harcama = harcamaListesi[position]

        with(holder.binding) {
            // Metin alanlarını doldur
            tvItemBaslik.text = harcama.baslik
            chipKategori.text = harcama.kategori
            tvItemTarih.text = harcama.tarih
            tvItemTutar.text = String.format("%.2f ₺", harcama.tutar)

            // Kategoriye göre sol renk çubuğunu değiştir
            val renk = when (harcama.kategori) {
                "Yiyecek & İçecek" -> android.graphics.Color.parseColor("#4CAF50")  // Yeşil
                "Ulaşım" -> android.graphics.Color.parseColor("#2196F3")             // Mavi
                "Eğlence" -> android.graphics.Color.parseColor("#9C27B0")            // Mor
                "Sağlık" -> android.graphics.Color.parseColor("#F44336")             // Kırmızı
                "Giyim" -> android.graphics.Color.parseColor("#FF9800")              // Turuncu
                "Faturalar" -> android.graphics.Color.parseColor("#607D8B")          // Gri
                "Eğitim" -> android.graphics.Color.parseColor("#009688")             // Teal
                else -> android.graphics.Color.parseColor("#6200EE")                  // Mor (varsayılan)
            }
            viewKategoriRenk.setBackgroundColor(renk)

            // Düzenle butonuna tıklama
            btnDuzenle.setOnClickListener {
                onDuzenleClick(harcama)
            }

            // Sil butonuna tıklama
            btnSil.setOnClickListener {
                onSilClick(harcama)
            }
        }
    }

    // Liste boyutunu döndür
    override fun getItemCount(): Int = harcamaListesi.size

    // Listeyi güncelle - yeni veri geldiğinde çağrılır
    fun listeGuncelle(yeniListe: List<Harcama>) {
        harcamaListesi.clear()
        harcamaListesi.addAll(yeniListe)
        notifyDataSetChanged()  // RecyclerView'i yenile
    }
}
