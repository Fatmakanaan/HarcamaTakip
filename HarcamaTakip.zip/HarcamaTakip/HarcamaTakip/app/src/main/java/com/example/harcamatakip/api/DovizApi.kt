package com.example.harcamatakip.api

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path

// Retrofit API arayüzü
// Kullanılan API: https://open.er-api.com (ücretsiz, kayıt gerektirmiyor)
interface DovizApi {

    // USD bazlı döviz kurlarını çek
    // Endpoint: https://open.er-api.com/v6/latest/USD
    @GET("v6/latest/{currency}")
    suspend fun dovizKurlariGetir(
        @Path("currency") currency: String = "USD"
    ): DovizResponse
}

// Retrofit istemcisi - tek seferlik oluşturulur
object RetrofitClient {

    private const val BASE_URL = "https://open.er-api.com/"

    // Lazy: ilk kullanıldığında oluşturulur
    val dovizApi: DovizApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())  // JSON -> Kotlin dönüşümü
            .build()
            .create(DovizApi::class.java)
    }
}
