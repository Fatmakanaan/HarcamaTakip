package com.example.harcamatakip

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.harcamatakip.adapter.HarcamaAdapter
import com.example.harcamatakip.database.Harcama
import com.example.harcamatakip.database.HarcamaDatabase
import com.example.harcamatakip.databinding.ActivityHistoryBinding
import com.example.harcamatakip.databinding.DialogHarcamaDuzenleBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import android.app.DatePickerDialog

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    private lateinit var harcamaDatabase: HarcamaDatabase
    private lateinit var harcamaAdapter: HarcamaAdapter

    // Tüm harcamalar listesi (filtreleme için tutulur)
    private var tumHarcamalar: List<Harcama> = emptyList()

    private val kategoriler = listOf(
        "Tümü",
        "Yiyecek & İçecek",
        "Ulaşım",
        "Eğlence",
        "Sağlık",
        "Giyim",
        "Faturalar",
        "Eğitim",
        "Diğer"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Toolbar'ı ayarla ve geri butonunu ekle
        setSupportActionBar(binding.toolbarHistory)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Veritabanını başlat
        harcamaDatabase = HarcamaDatabase.getDatabase(this)

        // RecyclerView kur
        recyclerViewKur()

        // Filtre dropdown'ını ayarla
        filtreAyarla()

        // Harcamaları yükle
        harcamalariYukle()
    }

    // Geri butonu işlevi
    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    // RecyclerView kurulumu
    private fun recyclerViewKur() {
        harcamaAdapter = HarcamaAdapter(
            mutableListOf(),
            onDuzenleClick = { harcama ->
                harcamaDuzenlemeDialogGoster(harcama)
            },
            onSilClick = { harcama ->
                silmeOnayiGoster(harcama)
            }
        )

        binding.recyclerViewHistory.apply {
            layoutManager = LinearLayoutManager(this@HistoryActivity)
            adapter = harcamaAdapter
        }
    }

    // Kategori filtresi dropdown kurulumu
    private fun filtreAyarla() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, kategoriler)
        binding.actvFiltre.setAdapter(adapter)
        binding.actvFiltre.setText("Tümü", false)

        // Filtre seçilince listeyi güncelle
        binding.actvFiltre.setOnItemClickListener { _, _, position, _ ->
            val secilenKategori = kategoriler[position]
            kategoriFiltrele(secilenKategori)
        }
    }

    // Kategoriye göre filtrele
    private fun kategoriFiltrele(kategori: String) {
        val filtreliListe = if (kategori == "Tümü") {
            tumHarcamalar
        } else {
            tumHarcamalar.filter { it.kategori == kategori }
        }

        harcamaAdapter.listeGuncelle(filtreliListe)
        istatistikleriGuncelle(filtreliListe)

        // Boş liste kontrolü
        if (filtreliListe.isEmpty()) {
            binding.tvBosListeHistory.visibility = View.VISIBLE
            binding.recyclerViewHistory.visibility = View.GONE
        } else {
            binding.tvBosListeHistory.visibility = View.GONE
            binding.recyclerViewHistory.visibility = View.VISIBLE
        }
    }

    // Veritabanından harcamaları yükle
    private fun harcamalariYukle() {
        lifecycleScope.launch {
            tumHarcamalar = harcamaDatabase.harcamaDao().tumHarcamalariGetir()

            runOnUiThread {
                // Filtreyi uygula (başlangıçta "Tümü")
                kategoriFiltrele("Tümü")
            }
        }
    }

    // Özet kartını güncelle
    private fun istatistikleriGuncelle(harcamalar: List<Harcama>) {
        val toplam = harcamalar.sumOf { it.tutar }
        binding.tvToplamHistory.text = String.format("%.2f ₺", toplam)
        binding.tvAdetHistory.text = "${harcamalar.size} adet"
    }

    // Düzenleme dialog'unu göster
    private fun harcamaDuzenlemeDialogGoster(harcama: Harcama) {
        val dialogBinding = DialogHarcamaDuzenleBinding.inflate(layoutInflater)

        // Mevcut değerleri doldur
        dialogBinding.etDuzenleBaslik.setText(harcama.baslik)
        dialogBinding.actvDuzenleKategori.setText(harcama.kategori)
        dialogBinding.etDuzenleTutar.setText(harcama.tutar.toString())
        dialogBinding.etDuzenleTarih.setText(harcama.tarih)

        // Kategori dropdown (Tümü hariç)
        val kategoriListesi = kategoriler.drop(1)  // "Tümü" yi çıkar
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, kategoriListesi)
        dialogBinding.actvDuzenleKategori.setAdapter(adapter)

        // Tarih seçici
        dialogBinding.etDuzenleTarih.setOnClickListener {
            tarihSeciciAc(dialogBinding.etDuzenleTarih)
        }
        dialogBinding.tilDuzenleTarih.setEndIconOnClickListener {
            tarihSeciciAc(dialogBinding.etDuzenleTarih)
        }

        val dialog = MaterialAlertDialogBuilder(this)
            .setView(dialogBinding.root)
            .setCancelable(true)
            .create()

        dialogBinding.btnDuzenleIptal.setOnClickListener { dialog.dismiss() }

        dialogBinding.btnDuzenleKaydet.setOnClickListener {
            val yeniBaslik = dialogBinding.etDuzenleBaslik.text.toString().trim()
            val yeniKategori = dialogBinding.actvDuzenleKategori.text.toString().trim()
            val yeniTutarStr = dialogBinding.etDuzenleTutar.text.toString().trim()
            val yeniTarih = dialogBinding.etDuzenleTarih.text.toString().trim()

            if (yeniBaslik.isEmpty() || yeniKategori.isEmpty() || yeniTutarStr.isEmpty() || yeniTarih.isEmpty()) {
                Snackbar.make(binding.root, "Tüm alanları doldurun!", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val yeniTutar = yeniTutarStr.toDoubleOrNull()
            if (yeniTutar == null || yeniTutar <= 0) {
                Snackbar.make(binding.root, "Geçerli bir tutar girin!", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val guncelHarcama = harcama.copy(
                baslik = yeniBaslik,
                kategori = yeniKategori,
                tutar = yeniTutar,
                tarih = yeniTarih
            )

            lifecycleScope.launch {
                harcamaDatabase.harcamaDao().harcamaGuncelle(guncelHarcama)
                runOnUiThread {
                    dialog.dismiss()
                    Snackbar.make(binding.root, "Harcama güncellendi!", Snackbar.LENGTH_SHORT).show()
                    harcamalariYukle()
                }
            }
        }

        dialog.show()
    }

    // Silme onayı
    private fun silmeOnayiGoster(harcama: Harcama) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Harcamayı Sil")
            .setMessage("\"${harcama.baslik}\" harcamasını silmek istiyor musunuz?")
            .setNegativeButton("İptal") { dialog, _ -> dialog.dismiss() }
            .setPositiveButton("Sil") { dialog, _ ->
                lifecycleScope.launch {
                    harcamaDatabase.harcamaDao().harcamaSil(harcama)
                    runOnUiThread {
                        dialog.dismiss()
                        Snackbar.make(binding.root, "Harcama silindi", Snackbar.LENGTH_SHORT).show()
                        harcamalariYukle()
                    }
                }
            }
            .show()
    }

    // Tarih seçici aç
    private fun tarihSeciciAc(editText: com.google.android.material.textfield.TextInputEditText) {
        val calendar = Calendar.getInstance()
        DatePickerDialog(
            this,
            { _, yil, ay, gun ->
                editText.setText(String.format("%04d-%02d-%02d", yil, ay + 1, gun))
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }
}
