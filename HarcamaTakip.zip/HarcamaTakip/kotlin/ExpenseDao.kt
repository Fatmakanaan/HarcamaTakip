package com.example.harcamatakip

import androidx.room.*

@Dao
interface ExpenseDao {

    @Insert
    fun insert(expense: Expense)

    @Update
    fun update(expense: Expense)

    @Delete
    fun delete(expense: Expense)

    @Query("SELECT * FROM expenses ORDER BY id DESC")
    fun getAll(): List<Expense>

    @Query("SELECT SUM(amount) FROM expenses")
    fun getTotalAmount(): Double?

    @Query("SELECT * FROM expenses WHERE category = :cat ORDER BY id DESC")
    fun getByCategory(cat: String): List<Expense>
}
