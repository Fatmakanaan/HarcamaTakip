package com.example.harcamatakip

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ExpenseAdapter(
    private val onEdit: (Expense) -> Unit,
    private val onDelete: (Expense) -> Unit
) : RecyclerView.Adapter<ExpenseAdapter.ViewHolder>() {

    private var list: List<Expense> = emptyList()

    fun submitList(newList: List<Expense>) {
        list = newList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_expense, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(list[position])
    }

    override fun getItemCount() = list.size

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvTitle    = itemView.findViewById<TextView>(R.id.tvItemTitle)
        private val tvCategory = itemView.findViewById<TextView>(R.id.tvItemCategory)
        private val tvAmount   = itemView.findViewById<TextView>(R.id.tvItemAmount)
        private val tvDate     = itemView.findViewById<TextView>(R.id.tvItemDate)
        private val btnEdit    = itemView.findViewById<ImageButton>(R.id.btnItemEdit)
        private val btnDelete  = itemView.findViewById<ImageButton>(R.id.btnItemDelete)

        fun bind(expense: Expense) {
            tvTitle.text    = expense.title
            tvCategory.text = expense.category
            tvAmount.text   = "₺%.2f".format(expense.amount)
            tvDate.text     = expense.date

            btnEdit.setOnClickListener   { onEdit(expense) }
            btnDelete.setOnClickListener { onDelete(expense) }
        }
    }
}
