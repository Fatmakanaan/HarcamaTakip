package com.example.harcamatakip

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = getSharedPreferences("user_prefs", MODE_PRIVATE)

        // Daha önce giriş yapıldıysa direkt MainActivity'e geç
        if (prefs.getBoolean("logged_in", false)) {
            goToMain()
            return
        }

        setContentView(R.layout.activity_login)

        val etUsername = findViewById<EditText>(R.id.etUsername)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnLogin   = findViewById<Button>(R.id.btnLogin)

        btnLogin.setOnClickListener {
            val user = etUsername.text.toString().trim()
            val pass = etPassword.text.toString().trim()

            when {
                user.isEmpty() || pass.isEmpty() ->
                    toast("Kullanıcı adı ve şifre boş bırakılamaz!")
                user == "admin" && pass == "1234" -> {
                    prefs.edit().putBoolean("logged_in", true).apply()
                    goToMain()
                }
                else -> toast("Kullanıcı adı veya şifre hatalı! (admin / 1234)")
            }
        }
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun toast(msg: String) =
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
