package com.example.harcamatakip

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private lateinit var adapter: ExpenseAdapter
    private lateinit var tvTotal: TextView
    private lateinit var tvRates: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = AppDatabase.getDatabase(this)

        tvTotal = findViewById(R.id.tvTotal)
        tvRates = findViewById(R.id.tvRates)

        // RecyclerView kurulumu
        val rv = findViewById<RecyclerView>(R.id.recyclerView)
        rv.layoutManager = LinearLayoutManager(this)
        adapter = ExpenseAdapter(
            onEdit   = { expense -> showDialog(expense) },
            onDelete = { expense ->
                AlertDialog.Builder(this)
                    .setTitle("Sil")
                    .setMessage("\"${expense.title}\" silinsin mi?")
                    .setPositiveButton("Evet") { _, _ ->
                        db.expenseDao().delete(expense)
                        loadExpenses()
                    }
                    .setNegativeButton("Hayır", null)
                    .show()
            }
        )
        rv.adapter = adapter

        // Buton tıklamaları
        findViewById<Button>(R.id.btnAdd).setOnClickListener     { showDialog(null) }
        findViewById<Button>(R.id.btnHistory).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<Button>(R.id.btnLogout).setOnClickListener  {
            getSharedPreferences("user_prefs", MODE_PRIVATE)
                .edit().putBoolean("logged_in", false).apply()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        loadExpenses()
        fetchRates()
    }

    override fun onResume() {
        super.onResume()
        loadExpenses()
    }

    // ── Liste & toplam ────────────────────────────────────────────────────────

    private fun loadExpenses() {
        val expenses = db.expenseDao().getAll()
        adapter.submitList(expenses)
        val total = db.expenseDao().getTotalAmount() ?: 0.0
        tvTotal.text = "Toplam: ₺%.2f".format(total)
    }

    // ── Ekle / Düzenle Dialog ─────────────────────────────────────────────────

    private fun showDialog(existing: Expense?) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_expense, null)
        val etTitle    = view.findViewById<EditText>(R.id.etDialogTitle)
        val spinner    = view.findViewById<Spinner>(R.id.spinnerCategory)
        val etAmount   = view.findViewById<EditText>(R.id.etDialogAmount)
        val etDate     = view.findViewById<EditText>(R.id.etDialogDate)

        val categories = listOf(
            "Yiyecek & İçecek", "Ulaşım", "Kira & Fatura",
            "Sağlık", "Giyim", "Eğlence", "Eğitim", "Diğer"
        )
        spinner.adapter = ArrayAdapter(this,
            android.R.layout.simple_spinner_dropdown_item, categories)

        // Düzenleme modunda alanları doldur
        if (existing != null) {
            etTitle.setText(existing.title)
            etAmount.setText(existing.amount.toString())
            etDate.setText(existing.date)
            val idx = categories.indexOf(existing.category)
            if (idx >= 0) spinner.setSelection(idx)
        } else {
            // Varsayılan tarih: bugün
            val today = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
            etDate.setText(today)
        }

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Harcama Ekle" else "Harcama Düzenle")
            .setView(view)
            .setPositiveButton("Kaydet") { _, _ ->
                val title  = etTitle.text.toString().trim()
                val cat    = spinner.selectedItem.toString()
                val amtStr = etAmount.text.toString().trim()
                val date   = etDate.text.toString().trim()

                if (title.isEmpty() || amtStr.isEmpty() || date.isEmpty()) {
                    Toast.makeText(this, "Tüm alanları doldurun!", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val amount = amtStr.toDoubleOrNull()
                if (amount == null || amount <= 0) {
                    Toast.makeText(this, "Geçerli bir tutar girin!", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                if (existing == null) {
                    db.expenseDao().insert(
                        Expense(title = title, category = cat, amount = amount, date = date)
                    )
                } else {
                    db.expenseDao().update(
                        existing.copy(title = title, category = cat, amount = amount, date = date)
                    )
                }
                loadExpenses()
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    // ── Döviz API ─────────────────────────────────────────────────────────────

    private fun fetchRates() {
        tvRates.text = "Döviz kurları yükleniyor..."
        thread {
            try {
                val json = URL("https://api.exchangerate-api.com/v4/latest/TRY").readText()
                val rates = JSONObject(json).getJSONObject("rates")
                val usd = rates.getDouble("USD")
                val eur = rates.getDouble("EUR")
                runOnUiThread {
                    tvRates.text = "1₺ = ${"%.5f".format(usd)} USD  |  ${"%.5f".format(eur)} EUR"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    tvRates.text = "Döviz bilgisi alınamadı"
                }
            }
        }
    }
}
