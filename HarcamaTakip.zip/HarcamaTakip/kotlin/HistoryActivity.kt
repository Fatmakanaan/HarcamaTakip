package com.example.harcamatakip

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HistoryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        val db = AppDatabase.getDatabase(this)
        val expenses = db.expenseDao().getAll()

        // ── İstatistik ────────────────────────────────────────────
        val total   = expenses.sumOf { it.amount }
        val count   = expenses.size
        val byCategory = expenses
            .groupBy { it.category }
            .mapValues { it.value.sumOf { e -> e.amount } }
            .toList()
            .sortedByDescending { it.second }

        val sb = StringBuilder()
        sb.appendLine("📊 Toplam Harcama : ₺%.2f".format(total))
        sb.appendLine("🧾 İşlem Sayısı   : $count adet")
        sb.appendLine()
        sb.appendLine("Kategoriye Göre:")
        byCategory.forEach { (cat, amt) ->
            sb.appendLine("  • %-22s ₺%.2f".format("$cat:", amt))
        }

        findViewById<TextView>(R.id.tvStats).text = sb.toString()

        // ── Liste ─────────────────────────────────────────────────
        val rv = findViewById<RecyclerView>(R.id.rvHistory)
        rv.layoutManager = LinearLayoutManager(this)

        // HistoryActivity'de düzenleme/silme yok, lambdalar boş
        val adapter = ExpenseAdapter(onEdit = {}, onDelete = {})
        rv.adapter = adapter
        adapter.submitList(expenses)
    }
}
